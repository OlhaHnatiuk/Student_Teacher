package students;

import java.util.Set;
import java.util.TreeSet;

public class Teacher extends Person {

	
	private Set<Student> students;
	
	
	public  Teacher(String name, String surname) throws IllegalArgumentException{
		super(name, surname);
		students = new TreeSet<>(new StudentComparator());
	}
	
	public void addStudent(Student s){
		students.add(s);
	}
	
	public void removeStudent(Student s){
		if(students.contains(s)){
			students.remove(s);
		}
	}
	
	public void printStudents(){
		for(Student i: students){
			System.out.print(i+"; ");
		}
		System.out.println();
	}
	
	
	
	
}
