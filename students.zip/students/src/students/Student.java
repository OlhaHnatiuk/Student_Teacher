package students;

import java.util.HashMap;
import java.util.Map;

public class Student extends Person{
	
	private Map<String, Integer> subjectMap;
	
	public Student(String name, String surname) throws IllegalArgumentException{
		super(name, surname);
		subjectMap = new HashMap<>();
	}
	
	public void addSubject(String subject){
		
		if(!super.isAlpha(subject)||subject.length()<2){
			
			System.out.println("Invalid input");
			return;
			
		}
		
		if(!subjectMap.containsKey(subject)){
			
			subjectMap.put(subject, null);
			
		}
	}
	
	public void setMark(String subject, int mark){
		
		if(subjectMap.containsKey(subject) && mark > 0 && mark <= 5){
			
			subjectMap.put(subject, mark);
			
		}
	}
	
	public void getSubjects(){
		for(String i: subjectMap.keySet()){
			System.out.print(i+" ");
		}
		System.out.println();
	}
	
	public void getMarks(){
		for(String i: subjectMap.keySet()){
			
			if(subjectMap.get(i)!=null){
				System.out.println(i + ": " + subjectMap.get(i));
			}
			else{
				System.out.println(i + ": " + "mark was not set");
			}
		}
	}
}
