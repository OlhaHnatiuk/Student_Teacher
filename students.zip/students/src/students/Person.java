package students;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

public class Person {
	private String name;
	private String surname;
	
	private String additionalInformation = null;
	private String e_mail = null;
	private String number = null;
	
	public Person(String name, String surname) throws IllegalArgumentException{
		
		if( !isAlpha(name) || !isAlpha(surname) || name.length()<2 || surname.length()<2 ){
			throw new IllegalArgumentException();
		}
		
		this.name = name;
		this.surname = surname;
	}
	
	public String getName(){
		return name;
	}
	
	public String getSurname(){
		return surname;
	}
	
	@Override
	public String toString(){
		return name + " " +surname;
	}
	
	public String getE_mail(){
		if(e_mail != null){
			return e_mail;
		}
		else{			
			return "E-mail is not given";
		}
	}
	
	public void setE_mail(String e_mail){
		boolean valid_mail = true;
		try {
		      InternetAddress emailAddr = new InternetAddress(e_mail);
		      emailAddr.validate();
		} catch (AddressException ex) {
			valid_mail = false;
		}
		if(valid_mail){
			this.e_mail = e_mail;
		}
		else{
			
			System.out.println("E-mail is not valid");
		}
	}
	
	public boolean isAlpha(String name) {
	    return name.matches("[a-zA-Z]+");
	}
	
	
	public String getInfo(){
		if(additionalInformation!=null){
			return additionalInformation;
		}
		else{
			return "Additional information is not given";
		}
	}
	
	public void setInfo(String info){
		additionalInformation = info;
	}
	
	public void setNumber(String number){
		String regexStr = "^[0-9]{10}$";
		if(number.matches(regexStr)){
			this.number = number;
		}
	}
	
	public String getNumber(){
		if(number!=null){
			return number;
		}
		else{
			return "Number is not set";
		}
	}
}
