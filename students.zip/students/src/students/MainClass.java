package students;

import java.util.ArrayList;
import java.util.List;

public class MainClass {
	
	static private List<Student> studentsList = new ArrayList<>();
	
	static private void addStudent(Student s){
		if(!studentsList.contains(s) && s!=null){
			studentsList.add(s);
		}
	}
	
	static private void delStudent(Student s){
		if(studentsList.contains(s)){
			studentsList.remove(s);
		}
	}
	
	static private void printAllList(){
		for(Student i: studentsList){
			System.out.println(i.toString());
		}
	}
	
	static private void sortList(){
		studentsList.sort(new StudentComparator());
	}
	public static void main(String[] argv){
		
		try{
			
			Student studentOne = new Student("Ann", "Bee"); MainClass.addStudent(studentOne);
			Student studentTwo = new Student("Rob", "Robber"); MainClass.addStudent(studentTwo);
			Student studentThree = new Student("Bin", "Bobber"); MainClass.addStudent(studentThree);
			
			Teacher teacherOfAll = new Teacher("Inna", "Zlotovska");
			for(Student i: MainClass.studentsList){
				teacherOfAll.addStudent(i);
			}
			
			MainClass.printAllList();
			MainClass.sortList();
			MainClass.printAllList();
			
			
			
			teacherOfAll.printStudents();
			
			studentOne.addSubject("Math");
			studentOne.setMark("Math", 3);
			studentOne.setMark("Math", -1);
			studentOne.addSubject("__");
			studentOne.addSubject("Probability");
			
			studentOne.setE_mail("ones@gmail.com");
			
			System.out.println(studentOne.getE_mail());
			studentOne.getMarks();
			
			MainClass.delStudent(studentThree);
			MainClass.delStudent(new Student("name", "surname"));
			MainClass.printAllList();
			
			Student studentError = new Student("###", ")))");
			
		}catch(IllegalArgumentException e){
			System.out.print(e);
		}
		
	}
}
